use only one of them

and open as admin if doesnt work

f1 to close